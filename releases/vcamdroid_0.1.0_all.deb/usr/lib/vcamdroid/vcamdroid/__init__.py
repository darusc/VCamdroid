"""VCamdroid Linux Client package."""
